<div class="alert alert-block alert-success">
								<button type="button" class="close" data-dismiss="alert">
									<i class="icon-remove"></i>
								</button>

								<i class="icon-ok green"></i>

								Selamat Datang
								<strong class="green">
									Sistem Akademik Online
									<small>(v1.1.2)</small>
								</strong>
								,
 the lightweight, feature-rich and easy to use admin template.
							</div>

							<div class="space-6"></div>