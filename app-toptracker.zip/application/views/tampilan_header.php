<!DOCTYPE html>
<html ng-app>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Top Tracker Store</title>
    <link href="<?=base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script type="text/javascript" src="<?=base_url();?>assets/bootstrap/js/bootstrap.min.js;?>"></script>
    <script type="text/javascript" src="<?=base_url('assets/bootstrap/js/bootstrap.js');?>"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/js/jquery-2.0.3.min.js"></script>
  </head>
  <style>
  a{
  	text-decoration: none;
  	color: black;
  }
  a:hover{
  	text-decoration: none;
  	color: black;
  }
  </style>
  <body background-color="white">
